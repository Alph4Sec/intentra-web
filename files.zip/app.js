/* ═══════════════════════════════════════════════════════════
   INTENTRA — app.js
   i18n EN/ES · Nav scroll · Time · Feed simulation
   Vanilla JS — no dependencies — CSP-safe
═══════════════════════════════════════════════════════════ */
'use strict';

/* ── i18n dictionary ── */
const STRINGS = {
  en: {
    nav_how:       'How It Works',
    nav_threats:   'Threats',
    nav_compare:   'vs. Alerting Tools',
    nav_roadmap:   'Roadmap',
    nav_cta:       'Install Free',

    hero_status:   'POLICY ENGINE ACTIVE',
    hero_status2:  'Ethereum Mainnet',
    hero_eyebrow:  'Zero-Trust Transaction Firewall',
    hero_line1:    'Zero trust',
    hero_line2:    'starts before',
    hero_line3:    'you sign.',
    hero_sub:      'INTENTRA intercepts every transaction before it reaches your wallet — simulates outcomes, enforces your policy, blocks threats. Pre-execution. Local. Zero external calls.',
    hero_cta1:     'Install Chrome Extension',
    hero_cta2:     'See how it works →',
    hero_proof1:   'Free',
    hero_proof2:   'No account required',
    hero_proof3:   'No external data transmission',

    mock_reason1:  'UNLIMITED_APPROVAL detected',
    mock_reason2:  'Contract not in Trusted list',
    mock_reason3:  'Spender unverified',
    mock_decision_label: 'ENFORCEMENT DECISION',
    mock_btn_deny: 'Block Transaction',
    mock_btn_review: 'Review',
    mock_feed_header: '// Recent decisions',

    stat1_num:   '12',
    stat1_label: 'Threat vectors covered',
    stat2_num:   '3',
    stat2_label: 'Enforcement modes',
    stat3_num:   '0',
    stat3_label: 'External calls made',
    stat4_num:   '100%',
    stat4_label: 'Local enforcement',
    stat5_num:   '0%',
    stat5_label: 'Fee on transactions',

    how_label:  '— 01 / HOW IT WORKS —',
    how_title1: 'Every transaction.',
    how_title2: 'Evaluated before it signs.',
    how_sub:    'INTENTRA sits between the dApp and your wallet. Every call goes through the engine — no exceptions, no bypasses.',

    pipe1_title: 'Intercept',
    pipe1_desc:  'Provider-level hook overrides window.ethereum via EIP-1193. Every eth_sendTransaction, signature request, and typed data call is captured before reaching the wallet.',
    pipe1_s1:    'EIP-1193 + EIP-6963 support',
    pipe1_s2:    'Payload capture at browser level',
    pipe1_s3:    'Transparent to dApp',

    pipe2_title: 'Simulate',
    pipe2_desc:  'Preflight execution against current on-chain state. Calldata is decoded to determine expected token movements, approval grants, and proxy implementation addresses.',
    pipe2_s1:    'Intent parsing + outcome modeling',
    pipe2_s2:    'Proxy detection (EIP-1967, UUPS, Beacon)',
    pipe2_s3:    'Block state validation',

    pipe3_title: 'Enforce',
    pipe3_desc:  'Policy evaluation against your active mode. Three deterministic outcomes: Allow, Review, or Deny. Out-of-policy transactions are blocked before the wallet signing prompt appears.',
    pipe3_s1:    'Zero-trust evaluation',
    pipe3_s2:    '3 configurable enforcement modes',
    pipe3_s3:    'Pre-signing execution block',

    pipe_note:   '// All evaluation runs locally in the browser extension. No transaction data leaves your machine.',

    threats_label: '— 02 / THREAT COVERAGE —',
    threats_title1: 'Every vector.',
    threats_title2: ' Blocked before signing.',
    threats_sub:   'V1 covers the attack surface where wallets offer no protection — the intent layer.',

    thr1_mode: 'Balanced: DENY',
    thr1_title: 'Unlimited Approvals',
    thr1_desc:  'Detects approve(MAX_UINT256) and equivalent patterns. Dormant approvals are the most common drainer vector. Blocked automatically.',
    thr1_spec:  'ERC-20 / ERC-721 / ERC-1155',

    thr2_mode: 'Balanced: REVIEW',
    thr2_title: 'Signature Abuse',
    thr2_desc:  'EIP-712 typed data and EIP-2612 Permit patterns decoded before the signing prompt. Off-chain authorizations evaluated against active policy.',
    thr2_spec:  'EIP-712 / EIP-2612 / Permit2',

    thr3_mode: 'Balanced: REVIEW',
    thr3_title: 'EIP-7702 Delegation Drain',
    thr3_desc:  'Detects accounts with delegated execution code. Malicious delegation patterns identified before ETH is forwarded to attacker-controlled addresses.',
    thr3_spec:  '0xef0100 prefix / eth_getCode',

    thr4_mode: 'Balanced: DENY',
    thr4_title: 'Velocity Attacks',
    thr4_desc:  'Kill switch auto-activates when transaction rate exceeds threshold. Cascading drain patterns — machine-speed approval bursts — stopped in-session.',
    thr4_spec:  'TX/min threshold / session-scoped',

    thr5_mode: 'Balanced: REVIEW',
    thr5_title: 'Proxy Contract Upgrades',
    thr5_desc:  'EIP-1967, UUPS, Beacon, and OpenZeppelin V2 proxy patterns detected. Recent implementation upgrades flagged — unverified implementations reviewed.',
    thr5_spec:  'EIP-1967 / UUPS / Beacon / OZ V2',

    thr6_mode: 'Balanced: REVIEW',
    thr6_title: 'Phishing Signatures',
    thr6_desc:  'Semantic analysis of signMessage calls. Obfuscated JSON, base64-encoded payloads, and disguised authorization patterns surfaced before signing.',
    thr6_spec:  'signMessage / typed data / base64',

    mode1_name: 'Permissive',
    mode1_desc: 'Alerts on critical threats. Minimal friction for power users who want visibility without enforcement.',
    mode2_name: 'Balanced',
    mode2_desc: 'Flags high-risk patterns for review. Blocks unlimited approvals and drainer patterns automatically.',
    mode3_name: 'Paranoid',
    mode3_desc: 'Maximum restriction. All out-of-policy execution blocked without prompt. Every threshold tightened.',

    comp_label:  '— 03 / VS ALERTING TOOLS —',
    comp_title1: 'Warning is not',
    comp_sub:    'Alerting tools require a human to interpret, decide, and act — correctly, under pressure, in real time. INTENTRA removes that dependency.',
    comp_col0:   'Dimension',
    comp_col1:   'Alerting Tools',
    comp_col2:   'INTENTRA',
    comp_dim1:   'Evaluation',
    comp1_bad:   'Heuristic signals. Output is a warning, not a decision.',
    comp1_good:  'Deterministic policy. Output is an enforcement action.',
    comp_dim2:   'Outcome',
    comp2_bad:   'User must abort manually after interpreting the alert.',
    comp2_good:  'Out-of-policy payloads blocked before the signing prompt.',
    comp_dim3:   'Failure Mode',
    comp3_bad:   'User error or social engineering overrides the warning.',
    comp3_good:  'Policy misconfiguration. Auditable and correctable.',
    comp_dim4:   'Fee',
    comp4_bad:   'Some charge up to 0.8% on every swap intercepted.',
    comp4_good:  'Zero fee. No transaction surcharge. Ever.',
    comp_dim5:   'Trust Model',
    comp5_bad:   'Correct human judgment under adversarial pressure.',
    comp5_good:  "Policy-driven. You configure the rules. The engine decides.",

    road_label:   '— 04 / ROADMAP —',
    road_title1:  'V1 is live.',
    road_title2:  ' The engine evolves.',
    road_sub:     'V1 establishes deterministic pre-execution enforcement. The roadmap extends toward deeper statefulness and institutional-grade resilience.',
    road_done:    '✓ V1 — LIVE',
    road_next:    '→ V1.5 — NEXT',
    road_planned: '○ PLANNED',

    road1_title: 'Policy Firewall — Chrome Extension',
    road1_desc:  'EIP-1193 interception, configurable policy engine, proxy detection, velocity kill switch, 12 threat vectors, local enforcement.',
    road2_title: 'Session Key Auditor',
    road2_desc:  'EIP-7702 and ERC-4337 session key evaluation. Spend limits, delegation duration, and permission scope reviewed before authorization. No competitor covers this for retail users today.',
    road3_title: 'Policy API — B2B Engine',
    road3_desc:  'The enforcement engine as a service. Wallets, protocols, and DAOs consume the policy layer via API to evaluate transactions before presenting them to users.',
    road4_title: 'Smart Account Modules',
    road4_desc:  'On-chain policy enforcement at the account layer. Guardian layer for institutional and DAO treasury operations. Policies portable and independent of the browser.',

    cta_label:  '— INSTALL —',
    cta_title1: 'Your wallet signs.',
    cta_title2: 'INTENTRA decides first.',
    cta_sub:    'Free Chrome extension. No account. No subscription. No transaction fees. Local enforcement — your policy, your browser, your rules.',
    cta_btn1:   'Add to Chrome — Free',
    cta_btn2:   'View on GitHub →',
    cta_proof1: 'Chrome Manifest V3',
    cta_proof2: 'TypeScript + ethers.js v6',
    cta_proof3: 'Open source',

    footer_tagline: 'Zero-Trust Transaction Firewall for Web3',
    footer_how:     'How it works',
    footer_threats: 'Threats covered',
    footer_comp:    'Comparison',
    footer_road:    'Roadmap',
    footer_install: 'Install',
    footer_rights:  'All rights reserved.',
    footer_build:   'Built with zero trust.',
  },

  es: {
    nav_how:      'Cómo Funciona',
    nav_threats:  'Amenazas',
    nav_compare:  'vs. Alertas',
    nav_roadmap:  'Hoja de Ruta',
    nav_cta:      'Instalar Gratis',

    hero_status:  'MOTOR DE POLÍTICAS ACTIVO',
    hero_status2: 'Ethereum Mainnet',
    hero_eyebrow: 'Firewall de Transacciones Zero-Trust',
    hero_line1:   'Zero trust',
    hero_line2:   'empieza antes',
    hero_line3:   'de firmar.',
    hero_sub:     'INTENTRA intercepta cada transacción antes de que llegue a tu wallet — simula resultados, aplica tu política, bloquea amenazas. Pre-ejecución. Local. Sin llamadas externas.',
    hero_cta1:    'Instalar Extensión Chrome',
    hero_cta2:    'Ver cómo funciona →',
    hero_proof1:  'Gratis',
    hero_proof2:  'Sin cuenta requerida',
    hero_proof3:  'Sin transmisión de datos externos',

    mock_reason1: 'UNLIMITED_APPROVAL detectado',
    mock_reason2: 'Contrato no en lista de confianza',
    mock_reason3: 'Spender no verificado',
    mock_decision_label: 'DECISIÓN DE IMPOSICIÓN',
    mock_btn_deny:   'Bloquear Transacción',
    mock_btn_review: 'Revisar',
    mock_feed_header: '// Decisiones recientes',

    stat1_num:   '12',
    stat1_label: 'Vectores de amenaza cubiertos',
    stat2_num:   '3',
    stat2_label: 'Modos de imposición',
    stat3_num:   '0',
    stat3_label: 'Llamadas externas realizadas',
    stat4_num:   '100%',
    stat4_label: 'Imposición local',
    stat5_num:   '0%',
    stat5_label: 'Comisión en transacciones',

    how_label:  '— 01 / CÓMO FUNCIONA —',
    how_title1: 'Cada transacción.',
    how_title2: 'Evaluada antes de firmar.',
    how_sub:    'INTENTRA se sitúa entre la dApp y tu wallet. Cada llamada pasa por el motor — sin excepciones, sin bypasses.',

    pipe1_title: 'Interceptar',
    pipe1_desc:  'Hook a nivel de proveedor anula window.ethereum vía EIP-1193. Cada eth_sendTransaction, solicitud de firma y typed data es capturado antes de llegar a la wallet.',
    pipe1_s1:    'Soporte EIP-1193 + EIP-6963',
    pipe1_s2:    'Captura de payload a nivel navegador',
    pipe1_s3:    'Transparente para la dApp',

    pipe2_title: 'Simular',
    pipe2_desc:  'Ejecución preflight contra el estado actual on-chain. El calldata se decodifica para determinar movimientos de tokens esperados, autorizaciones y direcciones de implementación proxy.',
    pipe2_s1:    'Análisis de intent + modelado de resultado',
    pipe2_s2:    'Detección proxy (EIP-1967, UUPS, Beacon)',
    pipe2_s3:    'Validación de estado del bloque',

    pipe3_title: 'Imponer',
    pipe3_desc:  'Evaluación de políticas según tu modo activo. Tres resultados deterministas: Allow, Review o Deny. Transacciones fuera de política bloqueadas antes del prompt de firma.',
    pipe3_s1:    'Evaluación zero-trust',
    pipe3_s2:    '3 modos de imposición configurables',
    pipe3_s3:    'Bloqueo de ejecución pre-firma',

    pipe_note:   '// Toda evaluación corre localmente en la extensión. Ningún dato de transacción sale de tu máquina.',

    threats_label:  '— 02 / COBERTURA DE AMENAZAS —',
    threats_title1: 'Cada vector.',
    threats_title2: ' Bloqueado antes de firmar.',
    threats_sub:    'V1 cubre la superficie de ataque donde las wallets no ofrecen protección — la capa de intent.',

    thr1_mode: 'Balanced: DENY', thr1_title: 'Aprobaciones Ilimitadas',
    thr1_desc: 'Detecta approve(MAX_UINT256) y patrones equivalentes. Las aprobaciones dormantes son el vector drainer más común. Bloqueadas automáticamente.',
    thr1_spec: 'ERC-20 / ERC-721 / ERC-1155',

    thr2_mode: 'Balanced: REVIEW', thr2_title: 'Abuso de Firmas',
    thr2_desc: 'Patrones EIP-712 typed data y EIP-2612 Permit decodificados antes del prompt de firma. Autorizaciones off-chain evaluadas contra política activa.',
    thr2_spec: 'EIP-712 / EIP-2612 / Permit2',

    thr3_mode: 'Balanced: REVIEW', thr3_title: 'Drain por Delegación EIP-7702',
    thr3_desc: 'Detecta cuentas con código de ejecución delegado. Patrones de delegación maliciosa identificados antes de que ETH sea reenviado a direcciones controladas por el atacante.',
    thr3_spec: '0xef0100 prefix / eth_getCode',

    thr4_mode: 'Balanced: DENY', thr4_title: 'Ataques de Velocidad',
    thr4_desc: 'Kill switch se activa automáticamente cuando la tasa de transacciones supera el umbral. Patrones de drain en cascada — ráfagas de aprobación a velocidad de máquina — detenidos en sesión.',
    thr4_spec: 'Umbral TX/min / alcance de sesión',

    thr5_mode: 'Balanced: REVIEW', thr5_title: 'Actualizaciones de Contratos Proxy',
    thr5_desc: 'Patrones proxy EIP-1967, UUPS, Beacon y OpenZeppelin V2 detectados. Actualizaciones de implementación recientes marcadas — implementaciones no verificadas revisadas.',
    thr5_spec: 'EIP-1967 / UUPS / Beacon / OZ V2',

    thr6_mode: 'Balanced: REVIEW', thr6_title: 'Firmas de Phishing',
    thr6_desc: 'Análisis semántico de llamadas signMessage. JSON ofuscado, payloads base64 y patrones de autorización disfrazados detectados antes de firmar.',
    thr6_spec: 'signMessage / typed data / base64',

    mode1_name: 'Permissive',
    mode1_desc: 'Alerta sobre amenazas críticas. Fricción mínima para usuarios avanzados que quieren visibilidad sin imposición.',
    mode2_name: 'Balanced',
    mode2_desc: 'Marca patrones de alto riesgo para revisión. Bloquea aprobaciones ilimitadas y patrones drainer automáticamente.',
    mode3_name: 'Paranoid',
    mode3_desc: 'Restricción máxima. Toda ejecución fuera de política bloqueada sin prompt. Cada umbral ajustado al máximo.',

    comp_label:  '— 03 / VS HERRAMIENTAS DE ALERTA —',
    comp_title1: 'Advertir no es',
    comp_sub:    'Las herramientas de alerta requieren que un humano interprete, decida y actúe — correctamente, bajo presión, en tiempo real. INTENTRA elimina esa dependencia.',
    comp_col0:   'Dimensión', comp_col1: 'Herramientas de Alerta', comp_col2: 'INTENTRA',
    comp_dim1:   'Evaluación',
    comp1_bad:   'Señales heurísticas. El output es una advertencia, no una decisión.',
    comp1_good:  'Política determinista. El output es una acción de imposición.',
    comp_dim2:   'Resultado',
    comp2_bad:   'El usuario debe abortar manualmente tras interpretar la alerta.',
    comp2_good:  'Payloads fuera de política bloqueados antes del prompt de firma.',
    comp_dim3:   'Modo de Falla',
    comp3_bad:   'Error humano o ingeniería social anula la advertencia.',
    comp3_good:  'Mala configuración de política. Auditable y corregible.',
    comp_dim4:   'Comisión',
    comp4_bad:   'Algunos cobran hasta 0.8% en cada swap interceptado.',
    comp4_good:  'Cero comisión. Sin recargo por transacción. Nunca.',
    comp_dim5:   'Modelo de Confianza',
    comp5_bad:   'Juicio humano correcto bajo presión adversarial.',
    comp5_good:  'Basado en políticas. Tú configuras las reglas. El motor decide.',

    road_label:   '— 04 / HOJA DE RUTA —',
    road_title1:  'V1 está en producción.',
    road_title2:  ' El motor evoluciona.',
    road_sub:     'V1 establece imposición determinista pre-ejecución. La hoja de ruta extiende hacia mayor statefulness y resiliencia institucional.',
    road_done:    '✓ V1 — EN PRODUCCIÓN',
    road_next:    '→ V1.5 — PRÓXIMO',
    road_planned: '○ PLANIFICADO',

    road1_title: 'Firewall de Políticas — Extensión Chrome',
    road1_desc:  'Interceptación EIP-1193, motor de políticas configurable, detección de proxy, kill switch de velocidad, 12 vectores de amenaza, imposición local.',
    road2_title: 'Auditor de Session Keys',
    road2_desc:  'Evaluación de session keys EIP-7702 y ERC-4337. Límites de gasto, duración de delegación y alcance de permisos revisados antes de la autorización. Ningún competidor cubre esto para usuarios retail hoy.',
    road3_title: 'Policy API — Motor B2B',
    road3_desc:  'El motor de imposición como servicio. Wallets, protocolos y DAOs consumen la capa de políticas vía API para evaluar transacciones antes de presentarlas a los usuarios.',
    road4_title: 'Smart Account Modules',
    road4_desc:  'Imposición de políticas on-chain en la capa de cuenta. Capa guardian para operaciones institucionales y de tesorería DAO. Políticas portables e independientes del navegador.',

    cta_label:  '— INSTALAR —',
    cta_title1: 'Tu wallet firma.',
    cta_title2: 'INTENTRA decide primero.',
    cta_sub:    'Extensión Chrome gratuita. Sin cuenta. Sin suscripción. Sin comisiones. Imposición local — tus reglas, tu navegador, tu política.',
    cta_btn1:   'Agregar a Chrome — Gratis',
    cta_btn2:   'Ver en GitHub →',
    cta_proof1: 'Chrome Manifest V3',
    cta_proof2: 'TypeScript + ethers.js v6',
    cta_proof3: 'Código abierto',

    footer_tagline: 'Firewall de Transacciones Zero-Trust para Web3',
    footer_how:     'Cómo funciona',
    footer_threats: 'Amenazas cubiertas',
    footer_comp:    'Comparación',
    footer_road:    'Hoja de ruta',
    footer_install: 'Instalar',
    footer_rights:  'Todos los derechos reservados.',
    footer_build:   'Construido con zero trust.',
  }
};

/* ── State ── */
let currentLang = localStorage.getItem('intentra_lang') || 'en';

/* ── Apply i18n ── */
function applyLang(lang) {
  currentLang = lang;
  localStorage.setItem('intentra_lang', lang);
  document.documentElement.setAttribute('lang', lang);
  document.documentElement.setAttribute('data-lang', lang);

  const dict = STRINGS[lang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key] !== undefined) {
      el.innerHTML = dict[key];
    }
  });

  // Update lang toggle button
  const btn = document.getElementById('langToggle');
  if (btn) btn.textContent = lang === 'en' ? 'EN / ES' : 'ES / EN';
}

/* ── Language toggle ── */
document.getElementById('langToggle')?.addEventListener('click', () => {
  applyLang(currentLang === 'en' ? 'es' : 'en');
});

/* ── Live clock ── */
function updateTime() {
  const now = new Date();
  const utc = now.toISOString().slice(11, 19) + ' UTC';
  const heroTime = document.getElementById('heroTime');
  const mockTime = document.getElementById('mockTime');
  if (heroTime) heroTime.textContent = utc;
  if (mockTime) mockTime.textContent = utc;
}
updateTime();
setInterval(updateTime, 1000);

/* ── Nav scroll behavior ── */
const nav = document.getElementById('nav');
let lastScroll = 0;

window.addEventListener('scroll', () => {
  const current = window.scrollY;
  if (current > 80) {
    nav?.classList.add('nav--scrolled');
  } else {
    nav?.classList.remove('nav--scrolled');
  }
  lastScroll = current;
}, { passive: true });

/* ── Mobile burger ── */
const burger = document.getElementById('navBurger');
const navLinks = document.querySelector('.nav-links');

burger?.addEventListener('click', () => {
  const expanded = burger.getAttribute('aria-expanded') === 'true';
  burger.setAttribute('aria-expanded', String(!expanded));
  navLinks?.classList.toggle('nav-links--open');
});

/* ── Smooth scroll for anchor links ── */
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const id = link.getAttribute('href').slice(1);
    const target = document.getElementById(id);
    if (target) {
      e.preventDefault();
      const offset = 70;
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
      navLinks?.classList.remove('nav-links--open');
    }
  });
});

/* ── Scroll-triggered fade-up animations ── */
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.pipe-step, .threat-card, .road-item, .mode-card, .stat-item').forEach(el => {
  el.classList.add('fade-up');
  observer.observe(el);
});

/* ── Live feed simulation ── */
const FEED_EVENTS = [
  { verdict: 'allow',  method: 'swap()',             proto: 'Uniswap V3'  },
  { verdict: 'deny',   method: 'approve(MAX_UINT256)', proto: 'Unknown'  },
  { verdict: 'allow',  method: 'transfer()',          proto: 'USDC'       },
  { verdict: 'review', method: 'setApprovalForAll()', proto: 'Unknown'   },
  { verdict: 'allow',  method: 'deposit()',           proto: 'Aave V3'   },
  { verdict: 'deny',   method: 'execute(bytes)',       proto: 'Unknown'  },
  { verdict: 'allow',  method: 'addLiquidity()',       proto: 'Uniswap'  },
  { verdict: 'review', method: 'permit()',             proto: 'Permit2'  },
  { verdict: 'allow',  method: 'stake()',              proto: 'Lido'     },
  { verdict: 'deny',   method: 'transferFrom()',       proto: '0xdead…'  },
];

let feedIndex = 0;

function addFeedItem() {
  const feedList = document.getElementById('feedList');
  if (!feedList) return;

  const event = FEED_EVENTS[feedIndex % FEED_EVENTS.length];
  feedIndex++;

  const now = new Date();
  const time = now.toISOString().slice(11, 19);

  const item = document.createElement('div');
  item.className = 'feed-item';
  item.style.opacity = '0';
  item.style.transition = 'opacity 0.4s ease';
  item.innerHTML = `
    <span class="feed-verdict feed-verdict--${event.verdict} font-mono">${event.verdict.toUpperCase()}</span>
    <span class="feed-method font-mono">${event.method}</span>
    <span class="feed-proto font-mono">${event.proto}</span>
    <span class="feed-time font-mono">${time}</span>
  `;

  // Add to top
  feedList.insertBefore(item, feedList.firstChild);
  requestAnimationFrame(() => { item.style.opacity = '1'; });

  // Remove oldest if more than 5
  while (feedList.children.length > 5) {
    const last = feedList.lastChild;
    if (last) {
      last.style.opacity = '0';
      setTimeout(() => last.remove(), 400);
    }
  }
}

// Start feed after 2s, then every 3-5s
setTimeout(() => {
  addFeedItem();
  setInterval(() => {
    addFeedItem();
  }, 3000 + Math.random() * 2000);
}, 2000);

/* ── Mockup cycling animation ── */
const MOCK_SCENARIOS = [
  {
    badge:    'INTERCEPTING',
    badgeColor: 'deny',
    label:   'TRANSACTION INTERCEPTED',
    method:  'approve(address,uint256)',
    methodColor: 'deny',
    contract: '0x1f98…1234 <span class="mock-tag">UNKNOWN</span>',
    spender:  '0xdeadbeef…cafe',
    amount:   'MAX_UINT256 ⚠',
    amountClass: 'text-deny',
    reasons: ['UNLIMITED_APPROVAL detected', 'Contract not in Trusted list', 'Spender unverified'],
    verdict: 'DENY',
    verdictClass: 'deny-pulse',
    verdictColor: 'var(--deny)',
  },
  {
    badge:    'EVALUATING',
    badgeColor: 'review',
    label:   'TRANSACTION INTERCEPTED',
    method:  'setApprovalForAll(address,bool)',
    methodColor: 'review',
    contract: '0x9f8f…abcd <span class="mock-tag">NEW</span>',
    spender:  '0x7fa8…3322',
    amount:   'true (all tokens)',
    amountClass: 'review-color',
    reasons: ['setApprovalForAll detected', 'Contract age < 7 days'],
    verdict: 'REVIEW',
    verdictClass: '',
    verdictColor: 'var(--review)',
  },
  {
    badge:    'CLEARED',
    badgeColor: 'allow',
    label:   'TRANSACTION CLEARED',
    method:  'swap(uint256,address)',
    methodColor: 'accent',
    contract: '0xe592…0000 <span class="mock-tag" style="color:var(--allow);background:rgba(0,214,143,0.1);border-color:rgba(0,214,143,0.2)">TRUSTED</span>',
    spender:  'Uniswap V3 Router',
    amount:   '1,500 USDC',
    amountClass: '',
    reasons: [],
    verdict: 'ALLOW',
    verdictClass: '',
    verdictColor: 'var(--allow)',
  },
];

let scenarioIndex = 0;

function cycleMockup() {
  scenarioIndex = (scenarioIndex + 1) % MOCK_SCENARIOS.length;
  const s = MOCK_SCENARIOS[scenarioIndex];

  const badge    = document.getElementById('mockupBadge');
  const method   = document.getElementById('mockMethod');
  const contract = document.getElementById('mockContract');
  const spender  = document.getElementById('mockSpender');
  const amount   = document.getElementById('mockAmount');
  const verdict  = document.getElementById('mockVerdict');
  const reasons  = document.getElementById('mockReasons');

  if (!badge || !method || !verdict) return;

  badge.textContent = '● ' + s.badge;
  badge.style.color = s.badgeColor === 'deny' ? 'var(--deny)'
                     : s.badgeColor === 'review' ? 'var(--review)'
                     : 'var(--allow)';

  if (method) {
    method.textContent = s.method;
    method.className = 'mock-val font-mono ' + (s.methodColor === 'deny' ? 'text-deny' : s.methodColor === 'review' ? 'review-color' : 'text-accent');
  }
  if (contract) contract.innerHTML = s.contract;
  if (spender) spender.textContent = s.spender;
  if (amount) {
    amount.textContent = s.amount;
    amount.className = 'mock-val font-mono ' + s.amountClass;
  }

  // Update reasons
  if (reasons) {
    reasons.innerHTML = '';
    if (s.reasons.length === 0) {
      const item = document.createElement('div');
      item.className = 'mock-reason mock-reason--active';
      item.innerHTML = '<span class="reason-icon" style="background:rgba(0,214,143,0.1);border-color:rgba(0,214,143,0.2);color:var(--allow)">✓</span><span class="font-mono">All policy checks passed</span>';
      reasons.appendChild(item);
    } else {
      s.reasons.forEach((r, i) => {
        const item = document.createElement('div');
        item.className = 'mock-reason';
        item.innerHTML = `<span class="reason-icon">×</span><span class="font-mono">${r}</span>`;
        reasons.appendChild(item);
        setTimeout(() => item.classList.add('mock-reason--active'), i * 150);
      });
    }
  }

  verdict.textContent = s.verdict;
  verdict.style.color = s.verdictColor;
  verdict.className = 'mock-decision-value font-mono ' + s.verdictClass;
}

// Cycle mockup every 6 seconds
setInterval(cycleMockup, 6000);

/* ── Init ── */
applyLang(currentLang);
